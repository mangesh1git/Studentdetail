package com.student.Service;

import java.util.List;

import com.student.model.Student;

public interface StudentService {

	public Student saveStudent(Student student);

	public Student getStudentDataById(Integer id);

	public void deleteStudent(Integer id);

	public Student updateStudentData(Integer id, Student student);

	public List<Student> getAllStudentData();
}
