package com.student.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.student.Service.StudentService;
import com.student.model.Student;

@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService studentservice;

	// for insert data
	@PostMapping("/insert")
	public ResponseEntity<Student> saveStudent(@RequestBody Student student) {
		Student s1 = studentservice.saveStudent(student);
		return ResponseEntity.ok().body(s1);
	}

	// for get the data
	@GetMapping("/getbyid/{id}")
	public ResponseEntity<Student> getPolicyDataById(@PathVariable("id") Integer id) {
		Student sl = studentservice.getStudentDataById(id);
		return ResponseEntity.ok().body(sl);
	}

	// for delete data
	@DeleteMapping("/delete/{id}")
	public void deleteStudent(@PathVariable("id") Integer id) {
		studentservice.deleteStudent(id);
	}

	// for update data
	@PutMapping("/updatedatabyid/{id}")
	public Student updateStudentData(@PathVariable("id") Integer id, @RequestBody Student student) {
		Student sl = studentservice.updateStudentData(id, student);
		return sl;
	}

	// for get all data
	@GetMapping("/getalldata")
	public List<Student> getAllStudentData() {
		List<Student> stud = (List<Student>) studentservice.getAllStudentData();
		return (List<Student>) stud;
	}
}