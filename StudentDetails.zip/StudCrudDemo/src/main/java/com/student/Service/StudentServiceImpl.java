package com.student.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.student.Repository.StudentRepository;
import com.student.model.Student;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepository studentRepository;
	
	//insert data
	@Override
	public Student saveStudent(Student student) {
		Student s1=studentRepository.save(student);
		return s1;
	}
	//get data by id
	@Override
	public Student getStudentDataById(Integer id) {
		Student student = studentRepository.findById(id);
		return student;
	}
	//delete data by id
	@Override
	public void deleteStudent(Integer id) {
		studentRepository.deleteById(id);
		
	}
	//update data by id
	@Override
	public Student updateStudentData(Integer id, Student student) {
		Student s2 = studentRepository.findById(id);
		s2.setfName(student.getfName());
		Student s3 = studentRepository.save(s2);
		return s3;
	}
	//get all data
	@Override
	public List<Student> getAllStudentData() {
		 return (List<Student>) studentRepository.findAll();
	}

}
